package com.example.lokeshkumar.splash;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.view.View.OnClickListener;


public class UploadFragment extends AppCompatActivity implements View.OnClickListener {




    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_upload);
        findViewById(R.id.gal).setOnClickListener(this);
        findViewById(R.id.pdf).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.gal:
                startActivity(new Intent(this, UploadImage.class));
                break;
            case R.id.pdf:
                startActivity(new Intent(this, UploadPdf.class));
                break;
        }
    }
    }






