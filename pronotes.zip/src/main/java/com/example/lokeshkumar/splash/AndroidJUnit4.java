package com.example.lokeshkumar.splash;

/**
 * Created by lokesh kumar on 9/2/2017.
 */

class AndroidJUnit4 {
}
