package com.example.lokeshkumar.splash;

/**
 * Created by lokesh kumar on 10/3/2017.
 */

public class UploadPdfSave {

    public String name;
    public String url;

    // Default constructor required for calls to
    // DataSnapshot.getValue(User.class)
    public UploadPdfSave() {
    }

    public UploadPdfSave(String name, String url) {
        this.name = name;
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }
}